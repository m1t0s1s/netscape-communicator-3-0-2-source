#include "prmon.h"

void PR_EnterMonitor(PRMonitor *mon)
{
}

int PR_ExitMonitor(PRMonitor *mon)
{
    return 0;
}
