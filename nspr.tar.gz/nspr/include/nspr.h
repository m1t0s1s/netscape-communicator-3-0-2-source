#ifndef nspr_h___
#define nspr_h___

#include "prtypes.h"
#include "prmacros.h"
#include "prosdep.h"
#include "prclist.h"
#include "prhash.h"
#include "prarena.h"
#include "prcpucfg.h"
#include "prlong.h"
#include "prfile.h"
#include "prmem.h"
#include "prglobal.h"
#include "prlink.h"
#include "prmon.h"
#include "prthread.h"
#include "prtime.h"
#include "prevent.h"
#include "prsystem.h"

#endif /* nspr_h___ */
