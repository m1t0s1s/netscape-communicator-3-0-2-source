#ifndef prtime_h___
#define prtime_h___

/*
** API to NSPR time functions. NSPR time is stored in a 64 bit integer
** and is relative to Jan 1st, 1970 GMT. Also, the units are in
** microseconds, so you need to divide it by 1,000,000 to convert to
** seconds.
*/
#include "prlong.h"
#include "prmacros.h"

NSPR_BEGIN_EXTERN_C

/*
** Broken down form of 64 bit time value.
*/
struct PRTimeStr {
    int32 tm_usec;		/* microseconds of second (0-999999) */
    int8 tm_sec;		/* seconds of minute (0-59) */
    int8 tm_min;		/* minutes of hour (0-59) */
    int8 tm_hour;		/* hour of day (0-23) */
    int8 tm_mday;		/* day of month (1-31) */
    int8 tm_mon;		/* month of year (0-11) */
    int8 tm_wday;		/* 0=sunday, 1=monday, ... */
    int16 tm_year;		/* absolute year, AD */
    int16 tm_yday;		/* day of year (0 to 365) */
    int8 tm_isdst;		/* non-zero if DST in effect */
};

/* Some handy constants */
#define PR_MSEC_PER_SEC		1000
#define PR_USEC_PER_SEC		1000000L
#define PR_NSEC_PER_SEC		1000000000L
#define PR_USEC_PER_MSEC	1000
#define PR_NSEC_PER_MSEC	1000000L

/* Return the current local time in micro-seconds */
extern PR_PUBLIC_API(int64) PR_Now(void);

/* Return the current local time, in milliseconds */
extern PR_PUBLIC_API(int64) PR_NowMS(void);

/* Return the current local time in seconds */
extern PR_PUBLIC_API(int64) PR_NowS(void);

/* Convert a local time value into a GMT time value */
extern PR_PUBLIC_API(int64) PR_ToGMT(int64 time);

/* Explode a 64 bit time value into its components */
extern PR_PUBLIC_API(void) PR_ExplodeTime(PRTime *to, int64 time);

/* Compute the 64 bit time value from the components */
extern PR_PUBLIC_API(int64) PR_ComputeTime(PRTime *tm);

/* Format a time value into a buffer. Same semantics as strftime() */
extern PR_PUBLIC_API(size_t) PR_FormatTime(char *buf, int buflen, char *fmt, 
                                           PRTime *tm);

/* Format a time value into a buffer. Time is always in US English format, regardless
 * of locale setting.
 */
extern PR_PUBLIC_API(size_t)
PR_FormatTimeUSEnglish( char* buf, size_t bufSize,
                        const char* format, const PRTime* time );

NSPR_END_EXTERN_C

#endif /* prtime_h___ */
