#ifndef prexc_h___
#define prexc_h___

/* Stubs for now */
#define PR_MarkException(a,b)	PR_ASSERT(!"PR_MarkException")

#define PR_CACHED_MONITOR_NOT_FOUND -1

#endif /* prexc_h___ */
